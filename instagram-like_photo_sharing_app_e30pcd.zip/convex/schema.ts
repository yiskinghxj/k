import { defineSchema, defineTable } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

const applicationTables = {
  photos: defineTable({
    storageId: v.id("_storage"),
    userId: v.id("users"),
    likes: v.number(),
  }).index("by_user", ["userId"]),
  
  likes: defineTable({
    photoId: v.id("photos"),
    userId: v.id("users"),
  }).index("by_photo_user", ["photoId", "userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
